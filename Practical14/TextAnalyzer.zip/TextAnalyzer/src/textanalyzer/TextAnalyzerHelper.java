/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package textanalyzer;

/**
 *
 * @author ramprasad
 */
public class TextAnalyzerHelper {
    
    private String inputText;
    
    private int textLength;
    private int wordCount;
    private int lineCount;
    private int tabCount;
    private int spaceCount;
    private String uniqueCharText;
    

    public int getTextLength() {
      
       
        return textLength;
    }

    public int getWordCount() {
        return wordCount;
    }

    public int getLineCount() {
        return lineCount;
    }

    public int getTabCount() {
        return tabCount;
    }

    public int getSpaceCount() {
        return spaceCount;
    }

     public int countCharacter(char ch) {
        int count = 0;
        for (int i = 0; i < inputText.length(); i++) {
            char current = inputText.charAt(i);
            if (Character.toLowerCase(current) == Character.toLowerCase(ch)) {
                count++;
            }
        }
        return count;
    }
     
   public int countWordsContainingChar(char selectedChar) 
   {
    int wordCount = 0;
    String[] words = inputText.split("\\s+"); 

    for (String word : words) 
    {
        if (word.toLowerCase().indexOf(Character.toLowerCase(selectedChar)) != -1) 
        {
            wordCount++;
        }
    }

    return wordCount;
}

    public TextAnalyzerHelper(String inputText) {
        this.inputText = inputText;
         analyze();
    }
    
   

    /*int getCharOrWordCount(String Text)
    {
            return 0;
    }
    */
    private void analyze()
    {
            /*textLength=inputText.length();
            lineCount=textLength>0?inputText.split("\n",-1).length:0;
            spaceCount=inputText.split(" ",-1).length;
            tabCount=inputText.split("\t",-1).length;
            //wordCount=inputText.split("\n",-1).length;*/
        
        
         textLength = inputText.length();

        lineCount = inputText.split("\r\n|\r|\n").length;

      
        String trimmed = inputText.trim();
        if (trimmed.isEmpty()) 
        {
            wordCount = 0;
        } 
        else 
        {
            wordCount = trimmed.split("\\s+").length;
        }

   
        spaceCount = (int) inputText.chars().filter(ch -> ch == ' ').count();
        tabCount = (int) inputText.chars().filter(ch -> ch == '\t').count();
        
        
    }

    @Override
    public String toString() {
        return "TextAnalyzerHelper{" + "inputText=" + inputText + ", textLength=" + textLength + ", wordCount=" + wordCount + ", lineCount=" + lineCount + ", tabCount=" + tabCount + ", spaceCount=" + spaceCount + ", uniqueCharText=" + uniqueCharText + '}';
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        TextAnalyzerHelper textSample = new TextAnalyzerHelper(" asdas@ \t\n");
        System.out.println(textSample);
    }
    
}
