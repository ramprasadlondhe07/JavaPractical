/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.employee_system;

/**
 *
 * @author RAMPRASAD
 */
class FrontendDeveloper extends Developer {
    String frontendFramework;

    FrontendDeveloper(String name, int id, double salary, String department, String programmingLanguage, String frontendFramework) {
        super(name, id, salary, department, programmingLanguage);
        this.frontendFramework = frontendFramework;
    }

    void designUI() {
        System.out.println(name + " is designing UI with " + frontendFramework);
    }
}