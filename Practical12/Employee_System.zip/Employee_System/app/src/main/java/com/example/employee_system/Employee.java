/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.employee_system;

/**
 *
 * @author RAMPRASAD
 */
class Employee {
    String name;
    int id;
    double salary;
    String department;

    // Constructor
    Employee(String name, int id, double salary, String department) {
        this.name = name;
        this.id = id;
        this.salary = salary;
        this.department = department;
    }

    void work() {
        System.out.println(name + " is working in " + department);
    }

    void getDetails() {
        System.out.println("ID: " + id + ", Name: " + name + ", Salary: " + salary + ", Department: " + department);
    }
}
