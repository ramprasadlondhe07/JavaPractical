/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.employee_system;

/**
 *
 * @author RAMPRASAD
 */
class Developer extends Employee {
    String programmingLanguage;

    Developer(String name, int id, double salary, String department, String programmingLanguage) {
        super(name, id, salary, department);
        this.programmingLanguage = programmingLanguage;
    }

    void writeCode() {
        System.out.println(name + " is coding in " + programmingLanguage);
    }
}