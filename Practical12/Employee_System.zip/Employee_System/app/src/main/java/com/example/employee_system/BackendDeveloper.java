/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.employee_system;

/**
 *
 * @author RAMPRASAD
 */
class BackendDeveloper extends Developer {
    String databaseTechnology;

    BackendDeveloper(String name, int id, int salary, String department, String programmingLanguage, String databaseTechnology) {
        super(name, id, salary, department, programmingLanguage);
        this.databaseTechnology = databaseTechnology;
    }

    void optimizeDatabase() {
        System.out.println(name + " is optimizing the " + databaseTechnology + " database.");
    }
}