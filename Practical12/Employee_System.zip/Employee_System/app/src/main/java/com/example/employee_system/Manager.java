/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.employee_system;

/**
 *
 * @author RAMPRASAD
 */
class Manager extends Employee {
    int teamSize;

    Manager(String name, int id, double salary, String department, int teamSize) {
        super(name, id, salary, department);
        this.teamSize = teamSize;
    }

    void conductMeeting() {
        System.out.println(name + " is conducting a meeting with " + teamSize + " team members.");
    }
}
